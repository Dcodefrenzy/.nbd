<aside id="sidebar">

  <!-- BEGIN .widget -->

  <div class="widget">
    <h3>LATEST ARTICLES</h3>
    <div class="widget-content ot-w-article-list">
      <?php getArticlePreview($conn) ?>
</div>
<!-- END .widget -->
</div>
<!-- BEGIN .widget -->

<!-- BEGIN .widget -->
<div class="widget">
<div class="widget-content">
<!--<a href="#" target="_blank"><img src="images/o2.jpg" alt="" /></a>-->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- box ads -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8913707638008127"
     data-ad-slot="9737468736"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<!-- END .widget -->
</div>

<!-- BEGIN .widget -->



<!-- BEGIN .widget -->
<div class="widget">
<h3>UPCOMING EVENTS</h3>
<div class="widget-content ot-w-comments-list">

<?php getPreviewEvent($conn) ?>

</div>
<!-- END .widget -->
</div>
<!-- BEGIN .widget -->


<!-- END #sidebar -->
</aside>
