<?php
    define("DBNAME", 'mckodevc_demo');
    define("DBUSER", 'mckodevc_web');
    define("DBPASS", 'Mckodevc@.02');

        try{

          $conn = new PDO('mysql:host=localhost;dbname='.DBNAME, DBUSER, DBPASS);

          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
        }
        catch(PDOException $e) {
                echo $e->getMessage();
        }

 ?>
